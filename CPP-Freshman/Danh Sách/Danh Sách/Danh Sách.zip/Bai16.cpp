﻿//#include "Ham16.h"
//int main()
//{
//	Node S1,S2;
//	// ------Tổ Hợp 1---------//
//	cout << "Nhap so phan tu trong to hop thu 1: ";
//	cin >> S1.n;
//	S1.Nhap( );
//	cout << "\n\t\tXuat to hop " << endl;
//	Rut_Gon( S1 ); // rút gọn rồi mới xuất
//	S1.Xuat();
//	// ------Tổ Hợp 2---------//
//	cout << "\nNhap so phan tu trong to hop thu 2: ";
//	cin >> S2.n;
//	S2.Nhap( );
//	cout << "\n\t\tXuat to hop " << endl;
//	Rut_Gon( S2 );// làm đẹp cho tổ hợp 2
//	S2.Xuat();
//	//Giao
//	cout << "\n A Giao B = { ";
//	Giao( S1,S2 );
//	cout << " } " << endl;
//	cout << "\n A \ B = { ";
//	Hieu( S1,S2 );
//	cout << " } " << endl;
//	system("pause");
//	return 0;
//}