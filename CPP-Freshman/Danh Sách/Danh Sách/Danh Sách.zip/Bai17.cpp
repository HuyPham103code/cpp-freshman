﻿//#include"bai17.h"
//int main()
//{
//	Set A,B;
//	//Nhập tổ hợp a
//	Input( A );
//	//Nhập tổ hợp b
//	Input( B );
//	cout << "A = ";
//	//Xuất 2 tỏ hợp
//	A.Print();
//	cout << "B = ";
//	B.Print();
//	//Hợp Hiệu Giao
//	Hop( A,B );
//	Hieu( A,B );
//	Giao( A,B );
//	//xóa các giá trị
//	A.Cannel();
//	B.Cannel();
//	system("pause");
//	return 0;
//}