﻿//#include "Bai14.h"
//int main()
//{
//	Node A,A1;
//	int n,n1;
//	//nhập đa thức thứ nhất
//	cout << "\n\t\tNhap da thuc thu 1 " << endl;
//	cout << "\n\tNhap sp luong phan tu trong da thuc: ";
//	cin >> n;
//	cout << "\n\tNhap da thuc " << endl;
//	A.Nhap(n);
//	//nhập đa thức thứ 2
//	cout << "\n\t\tNhap da thuc thu 2 " << endl;
//	cout << "\n\tNhap sp luong phan tu trong da thuc: ";
//	cin >> n1;
//	cout << "\n\tNhap da thuc " << endl;
//	A1.Nhap(n1);
//	system("cls");
//	//rút gọn lại 2 đa thức vừa nhập
//	cout << "\n\tRut gon da thuc thu 1" << endl;
//	A.Rut_Gon(n);
//	A.Xuat(n);
//	cout << "\n\tRut gon da thuc thu 2" << endl;
//	A1.Rut_Gon(n1);
//	A1.Xuat(n1);
//	//Cộng 2 đa thức
//	cout << "\n\t\tCong 2 da thuc " << endl;
//	Cong( A.s,A1.s,n,n1 );
//	//Trừ 2 đa thức
//	cout << "\n\t\tTru 2 da thuc " << endl;
//	Tru( A.s,A1.s,n,n1 );
//	//Nhân 2 đa thức
//	cout << "\n\t\tNhan 2 da thuc " << endl;
//	Nhan( A.s,A1.s,n,n1 );
//	system("pause");
//	return 0;
//}